<?php 
//echo '<h3>'.'Punto 2-A - Arreglo Asociativo'.'</h3>';
$arrayinformacion = array
(
	array('Id' => 10,
		  'Dni' => 37534790,
		  'Estado' => 'Ac',
		  'Telefono' => 3704564895
		  ),
	array('Id' => 29,
		  'Dni' => 31072642,
		  'Estado' => 'Ac',
		  'Telefono' => 3705238745
		  ),
	array('Id' => 34,
		  'Dni' => 31495856,
		  'Estado' => 'Ac',
		  'Telefono' => 3704214589
		  ),
	array('Id' => 45,
		  'Dni' => 28827535,
		  'Estado' => 'Ac',
		  'Telefono' => 3718256489
		  ),
	array('Id' => 52,
		  'Dni' => 38573714,
		  'Estado' => 'Ac',
		  'Telefono' => 3704564895
		  ),
	array('Id' => 65,
		  'Dni' => 20525869,
		  'Estado' => 'Ac',
		  'Telefono' => 3705238745
		  ),
	array('Id' => 79,
		  'Dni' => 37535571,
		  'Estado' => 'Ac',
		  'Telefono' => 3704214589 
		  ),
	array('Id' => 84,
		  'Dni' => 16969416,
		  'Estado' => 'Ac',
		  'Telefono' => 3718256489
		  ),
	array('Id' => 9,
		  'Dni' => 39136464,
		  'Estado' => 'Ac',
		  'Telefono' => 3704564895
		  ),
	array('Id' => 103,
		  'Dni' => 40084200,
		  'Estado' => 'Ac',
		  'Telefono' => 3705238745
		  ),
	array('Id' => 117,
		  'Dni' => 39133013,
		  'Estado' => 'Ac',
		  'Telefono' => 3704214589
		  ),
	array('Id' => 124,
		  'Dni' => 5038619,
		  'Estado' => 'Ac',
		  'Telefono' => 3718256489
		  ),
);

//print_r($arrayinformacion)
/*echo '<ul>';
foreach ($arrayinformacion as $Alumnos => $Datos)
{
    echo "<li>$Alumnos</li>\n<ul>\n";
    foreach ($Datos as $Datos)
    {
        echo "    <li>$Datos</li>\n";
    }
    echo "</ul>\n\n";
}
echo '</ul>';*/


?>
